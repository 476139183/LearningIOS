#!/bin/bash


for i in {0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0}
do
   outP="com"$i".jpeg"
   #echo $outP
   ./JPEGCompress ./IMG_0420.PNG ./$outP $i
done

