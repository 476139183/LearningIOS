//
//  main.m
//  JPEGCom
//
//  Created by cocoa on 17/4/20.
//  Copyright © 2017年 dev.keke@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
